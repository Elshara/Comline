<?php

require_once $_SERVER['DOCUMENT_ROOT'] . '/test/WebTestGroupRunner.php';

$wtgr = new WebTestGroupRunner();
$wtgr->run();
