<?php
define('NF_APP_BASE',dirname(__FILE__));
require_once NF_APP_BASE . '/lib/index.php';

