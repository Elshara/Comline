<?php
/**
 * @mainpage
 *
 * Bazel is Ning's "Your Own Social Network" application.
 */

/**
 * The XG namespace is used for shared, application-wide classes.
 *
 * @package XG
 */