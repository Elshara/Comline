<?php /* spacer.gif is used for measurement [Jon Aquino 2008-05-19] */ ?>
<img src="<%=xnhtmlentities(xg_url('/xn_resources/widgets/index/gfx/spacer.gif', array("msgtype"=>$msgtype)))%>" width="1" height="1" alt="">
</body>
</html>