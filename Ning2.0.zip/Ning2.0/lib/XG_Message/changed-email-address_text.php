<%= xg_text('YOU_CHANGED_YOUR_EMAIL_ON_X', $message['appName']) %>


<%= xg_text('CLICK_HERE_TO_SIGN_IN_WITH_YOUR_NEW_EMAIL_ADDRESS') %>

<%= $signInUrl %>


<%= xg_text('IF_DID_NOT_CHANGE_EMAIL_ADDRESS') %>

<%= $contactUsUrl %>

<%= $message['appName'] %>
